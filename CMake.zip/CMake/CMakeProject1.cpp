﻿// CMakeProject1.cpp: define el punto de entrada de la aplicación.
//

#include "CMakeProject1.h"

#include <iostream>
#include <fstream>
#include <chrono>
#include <ctime>

int main() {
    // Mostrar mensaje en consola
    std::cout << "Hola, mundo!" << std::endl;

    // Obtener la fecha y hora actual usando <chrono> y <ctime>
    auto now = std::chrono::system_clock::now();
    std::time_t now_time = std::chrono::system_clock::to_time_t(now);
    std::tm* now_tm = std::localtime(&now_time);

    // Crear un archivo de registro y escribir la fecha y hora
    std::ofstream log_file("log.txt");
    if (log_file.is_open()) {
        log_file << "Fecha y hora: " << std::asctime(now_tm);
        log_file.close();
    }
    else {
        std::cerr << "No se pudo abrir el archivo de log!" << std::endl;
    }

    return 0;
}
